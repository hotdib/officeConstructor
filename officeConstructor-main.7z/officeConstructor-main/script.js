const container = document.getElementById("map_container");
const popup = document.getElementById("popup");
const inputPopup = document.getElementById("inputPopup");
const buttonAdd = document.getElementById("buttonAdd");
const popupCloseButton = document.getElementById("popupClose");
const routeButton = document.getElementById("routeButton");

let coordX, coordY;
let isDragging = false; // флаг для отслеживания перемещения
let dragTimeout = null; // Флаг для определения задержки после завершения перетаскивания
let currentLi = null; // Текущий элемент li, над которым находится мышь

// Функция для получения координат клика на карте
function coordinates(event) {
    coordX = event.clientX;
    coordY = event.clientY;
}

// Открыть всплывающее окно
function popupOpen() {
    popup.classList.add("active");
    popup.disabled = false;
    inputPopup.focus();
}

// Закрыть всплывающее окно
function popupClose() {
    popup.classList.remove("active");
    popup.disabled = true;
    inputPopup.value = "";
}

// Добавляем обработчик клика на контейнер (карту)
container.addEventListener('click', function (event) {
    if (!isDragging && !dragTimeout) {  // Открываем popup только если не было перетаскивания
        coordinates(event);
        popupOpen();
    }
    dragTimeout = null;  // Сбрасываем флаг после клика
});

// Функция для добавления нового офиса на карту
function addNewWaypoint() {
    const newWaypoint = document.createElement("li");
    newWaypoint.textContent = inputPopup.value;
    container.append(newWaypoint);

    newWaypoint.setAttribute("style", `top: ${coordY}px; left: ${coordX}px;`);

    // Добавляем возможность перетаскивать новые офисы
    addDragFunctionality(newWaypoint);
    addDeleteFunctionality(newWaypoint); // Добавляем функционал удаления
}

// Добавляем перетаскивание для элементов <li>
function addDragFunctionality(liElement) {
    liElement.addEventListener('mousedown', function (event) {
        coordX = event.clientX;
        coordY = event.clientY;
        isDragging = true; // Устанавливаем флаг, что началось перетаскивание

        liElement.setAttribute("style", `top: ${coordY}px; left: ${coordX}px;`);

        // Добавляем событие перемещения элемента при движении мыши
        document.addEventListener('mousemove', moveElement);

        function moveElement(event) {
            coordX = event.clientX;
            coordY = event.clientY;
            liElement.style.top = `${coordY}px`;
            liElement.style.left = `${coordX}px`;
        }

        // Убираем событие перемещения при отпускании мыши
        document.addEventListener('mouseup', function () {
            document.removeEventListener('mousemove', moveElement);
            isDragging = false; // Перетаскивание завершилось

            // Устанавливаем задержку после отпускания мыши, чтобы избежать вызова события клика
            dragTimeout = setTimeout(() => {
                dragTimeout = null;
            }, 50);  // Небольшая задержка, чтобы клик не сработал после перетаскивания
        }, { once: true }); // событие должно сработать один раз
    });
}

// Добавляем возможность удаления элемента <li>
function addDeleteFunctionality(liElement) {
    liElement.addEventListener('mouseenter', () => {
        currentLi = liElement; // Сохраняем текущий элемент, над которым мышка
    });

    liElement.addEventListener('mouseleave', () => {
        currentLi = null; // Убираем элемент, если мышка ушла
    });
}

// Удаление элемента при нажатии клавиши Delete
document.addEventListener('keydown', (event) => {
    if (event.key === 'Delete' && currentLi) {
        currentLi.remove(); // Удаляем текущий элемент
        currentLi = null; // Сбрасываем переменную
    }
});

// Обработчик кнопки добавления нового элемента
buttonAdd.addEventListener('click', function () {
    if (inputPopup.value != "") {
        sendOfficeName();
    }
});

// Функция для добавления нового офиса и закрытия popup
function sendOfficeName() {
    addNewWaypoint();
    popupClose();
}

// Обработчик нажатия клавиши Enter в поле ввода
inputPopup.addEventListener('keydown', function (event) {
    if (event.key === 'Enter' && inputPopup.value != "") {
        event.preventDefault(); // Предотвращаем стандартное поведение Enter (если нужно)
        sendOfficeName();
    }
});

// Закрытие всплывающего окна при нажатии кнопки
popupCloseButton.addEventListener('click', function () {
    if (popup.classList.contains("active") || popup.disabled == false) {
        popupClose();
    }
});

// Применяем функции для уже существующих <li> элементов (если они есть)
document.querySelectorAll("li").forEach(addDragFunctionality);
document.querySelectorAll("li").forEach(addDeleteFunctionality);





//================ Начало логики =============

const startOffice = document.getElementById('start-office');

const endOffice = document.getElementById('end-office');

let waypoint = document.querySelectorAll("li");


function makeRoute(){
    let moreless = startOffice.value < endOffice.value;
    console.log(startOffice.value);
    console.log(endOffice.value);
    console.log(moreless);
    
    function routeMaker(){
        let pointA = startOffice.value;
        let pointB = endOffice.value;
        let position = waypoint.value;




        
	    if (position == startOffice.value){
            if (moreless == true) {
                while (moreless == true){
                    //Проверить существует ли Ли со значением плюс один, если да то
                    console.log("moreless = true");
                    break;
                }
            } else {
                while (moreless == false){
                    //Проверить существует ли Ли со значением плюс один, если да то
                    console.log("moreless = false");
                    break;
                }
            }   



	    }
    };
    waypoint.forEach(routeMaker);
};

// Обработчик кнопки создания маршрута
routeButton.addEventListener('click', function (event) {
    event.preventDefault();
    if (startOffice.value != "" && endOffice.value != "") {
        makeRoute();
    } else {
        console.log("input empty")
    }
});
